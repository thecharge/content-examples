"""Carry the original contextual learner through the growing graph."""

from collections import deque


from graph import GraphState
from contextual import ContextFeedback
from learn import Example


class ReplayBoard:
    """The native feedback protocol, with full graph replay and private states."""

    def __init__(self, graph):
        self.graph = graph

    @property
    def outputs(self):
        return self.graph.cores["b0"].outputs

    @property
    def correction(self):
        return self.graph.cores["b0"].correction

    def context(self, rows):
        return self.graph.cores["b0"].context(rows)

    def start(self, inputs):
        return GraphState()

    def __deepcopy__(self, memo):
        return ReplayBoard(self.graph.fork())

    def __call__(self, inputs, minutes, before, *, checks=True):
        if not checks:
            raise ValueError("Contextual replay retains the native checkers")
        stamp = (
            max(float(t.max()) for t in before.stamps.values())
            if before.stamps
            else 0.0
        ) + float(minutes.max()) * 60
        return self.graph(inputs, minutes, before, stamp=stamp)


def create(graph, settings, *, stream=False):
    learner = (StreamFeedback if stream else ContextFeedback)(ReplayBoard(graph))
    learner.minimum = settings.window
    learner.minority = settings.minority
    learner.history = tuple(deque(maxlen=settings.history) for _ in range(2))
    return learner


def pack(learner):
    from runtime import pack_state

    def example(item):
        return dict(
            timestamp=item.timestamp,
            inputs=item.inputs,
            before=pack_state(item.before),
            truth=item.truth,
            reward=item.reward,
        )

    return dict(
        stream=isinstance(learner, StreamFeedback),
        history=[[example(x) for x in queue] for queue in learner.history],
        check=[example(x) for x in learner.check],
        latest=learner.latest,
        receipts=learner.receipts,
        origin=learner.origin,
    )


def restore(graph, settings, payload):
    from runtime import unpack_state

    learner = create(graph, settings, stream=payload.get("stream", False))

    def example(item):
        return Example(
            item["timestamp"],
            item["inputs"],
            unpack_state(item["before"]),
            item["truth"],
            item["reward"],
        )

    learner.history = tuple(
        deque((example(x) for x in queue), maxlen=settings.history)
        for queue in payload["history"]
    )
    learner.check = [example(x) for x in payload["check"]]
    learner.latest, learner.receipts = payload["latest"], payload["receipts"]
    learner.origin = payload["origin"]
    return learner


def stream_predictions(model, examples):
    """Replay real event clocks; gaps use the recorded private pre-event state."""
    import torch

    state, previous = examples[0].before, None
    answers, probabilities, committed = [], [], []
    for item in examples:
        if previous is not None and item.timestamp - previous != 300:
            state = item.before
        root = state.stamps.get("b0")
        minutes = 5.0 if root is None else (item.timestamp - float(root[0])) / 60
        result = model.graph(
            item.inputs, item.inputs.new_tensor([minutes]), state, stamp=item.timestamp
        )
        answers.append(result.answer)
        probabilities.append(result.probability)
        committed.append(result.committed)
        state, previous = result.state.detached(), item.timestamp
    return tuple(torch.cat(v) for v in (answers, probabilities, committed))


class StreamFeedback(ContextFeedback):
    """Native residual fitting with actual clocks and a strict local no-harm gate."""

    def try_update(self, fit, check):
        from copy import deepcopy
        import torch
        from torch import nn
        from torch.nn import functional as F
        from reference import by_class, paired_margin

        if fit[-1].timestamp >= check[0].timestamp:
            raise ValueError("Fit and check intervals overlap")
        expected = torch.cat([item.truth for item in fit])
        if int(expected.bincount(minlength=2).min()) < self.minority:
            return dict(status="frozen_recent_history_one_class", accepted=[])
        with torch.no_grad():
            old_answer, old_probability, _ = stream_predictions(self.model, fit)
            inputs = self.model.context(torch.cat([item.inputs for item in fit]))
            prior = torch.logit(old_probability.clamp(0.01, 0.99))
        residual = nn.Parameter(torch.zeros_like(self.model.correction))
        optimizer = torch.optim.Adam([residual], lr=0.04)
        for _ in range(60):
            optimizer.zero_grad()
            error = F.binary_cross_entropy_with_logits(
                prior + inputs @ residual, expected.float(), reduction="none"
            )
            loss = by_class(error, expected) + 0.08 * residual.square().sum()
            loss.backward()
            optimizer.step()
        candidate = deepcopy(self.model)
        best = None
        with torch.no_grad():
            for step in (0.25, 0.5, 1.0):
                moved = (self.model.correction + step * residual.detach()).clamp(
                    -0.8, 0.8
                )
                candidate.correction.copy_(moved)
                answers, probability, _ = stream_predictions(candidate, fit)
                gain = float(
                    by_class(
                        answers.eq(expected).float() - old_answer.eq(expected).float(),
                        expected,
                    )
                )
                brier = float(
                    by_class(
                        (old_probability - expected).square()
                        - (probability - expected).square(),
                        expected,
                    )
                )
                if gain > 0 and (best is None or (gain, brier) > best[:2]):
                    best = gain, brier, step, moved.clone()
            details = dict(
                fit_first=fit[0].timestamp,
                fit_last=fit[-1].timestamp,
                fit_rows=len(fit),
                check_rows=len(check),
                accepted=[],
            )
            if best is None:
                return dict(details, status="frozen_no_fit_gain")
            candidate.correction.copy_(best[3])
            a, p, q = stream_predictions(self.model, check)
            b, r, s = stream_predictions(candidate, check)
            truth = torch.cat([item.truth for item in check])
            delta = b.eq(truth).float() - a.eq(truth).float()
            gain = float(by_class(delta, truth))
            brier = float(by_class((p - truth).square() - (r - truth).square(), truth))
            classes = [float(delta[truth == c].mean()) for c in (0, 1)]
            quorum = float((s.float() - q.float()).mean())
            lower = paired_margin(delta, truth)
            accepted = (
                gain >= 0.01
                and brier >= 0.002
                and lower is not None
                and lower > 0
                and min(classes) >= 0
                and quorum >= 0
            )
            if accepted:
                self.model.correction.copy_(best[3])
                details["accepted"] = ["stream contextual readout"]
            return dict(
                details,
                status="accepted" if accepted else "frozen_no_board_gain",
                board_gain=dict(
                    accuracy_gain=gain,
                    brier_gain=brier,
                    accuracy_lower=lower,
                    class_gain=classes,
                    quorum_gain=quorum,
                ),
            )
